const constants = {

    SERVER:'http://localhost:5000/',
    FIREBASE:"https://controlhub-881eb-default-rtdb.firebaseio.com/"
}
export default constants;